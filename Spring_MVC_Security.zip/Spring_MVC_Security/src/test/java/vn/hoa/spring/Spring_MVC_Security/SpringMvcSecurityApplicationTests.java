package vn.hoa.spring.Spring_MVC_Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
