package vn.hoa.spring.Spring_MVC_11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvc11Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvc11Application.class, args);
	}

}
