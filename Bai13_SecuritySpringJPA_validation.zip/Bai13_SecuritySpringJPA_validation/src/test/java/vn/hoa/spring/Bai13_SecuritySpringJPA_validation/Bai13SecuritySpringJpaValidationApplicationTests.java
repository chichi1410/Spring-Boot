package vn.hoa.spring.Bai13_SecuritySpringJPA_validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bai13SecuritySpringJpaValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
