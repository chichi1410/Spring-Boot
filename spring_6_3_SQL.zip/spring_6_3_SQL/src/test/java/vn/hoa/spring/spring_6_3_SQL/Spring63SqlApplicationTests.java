package vn.hoa.spring.spring_6_3_SQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring63SqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
